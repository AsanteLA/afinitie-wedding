/* ============================================================
   AFINITIE WEDDING — RSVP LAMBDA FUNCTION

   Receives RSVP form data, saves to DynamoDB, and emails
   Asante & Abbie via SES.

   AWS Services used:
   - API Gateway (trigger)
   - Lambda (this function)
   - DynamoDB (stores RSVPs)
   - SES (sends email notification)
   ============================================================ */

const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');
const { SESClient, SendEmailCommand }    = require('@aws-sdk/client-ses');
const { randomUUID }                     = require('crypto');

const dynamo = new DynamoDBClient({ region: process.env.AWS_REGION });
const ses    = new SESClient({ region: process.env.AWS_REGION });

// ---- CONFIGURE THESE ----
const TABLE_NAME   = process.env.RSVP_TABLE   || 'afinitie-rsvps';
const NOTIFY_EMAIL = process.env.NOTIFY_EMAIL || 'alaryea-akrong@trovebrands.com'; // must be SES-verified
const FROM_EMAIL   = process.env.FROM_EMAIL   || 'alaryea-akrong@trovebrands.com'; // must be SES-verified
// -------------------------

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

exports.handler = async (event) => {

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS, body: '' };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  const { name, email, attending, guests, dietary, song, message, timestamp } = body;

  // Basic validation
  if (!name || !email || !attending) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: 'Missing required fields' }) };
  }

  const id = randomUUID();
  const ts = timestamp || new Date().toISOString();

  // Save to DynamoDB
  try {
    await dynamo.send(new PutItemCommand({
      TableName: TABLE_NAME,
      Item: {
        id:        { S: id },
        name:      { S: name },
        email:     { S: email },
        attending: { S: attending },
        guests:    { S: guests    || '0' },
        dietary:   { S: dietary   || '' },
        song:      { S: song      || '' },
        message:   { S: message   || '' },
        timestamp: { S: ts },
      },
    }));
  } catch (err) {
    console.error('DynamoDB error:', err);
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: 'Failed to save RSVP' }) };
  }

  // Send email notification via SES
  const isAttending = attending === 'yes';
  const emailBody = [
    `New RSVP from ${name}`,
    ``,
    `Attending:   ${isAttending ? 'YES 🎉' : 'No 😢'}`,
    `Name:        ${name}`,
    `Email:       ${email}`,
    isAttending ? `Guests:      ${guests}` : '',
    isAttending && dietary  ? `Dietary:     ${dietary}` : '',
    isAttending && song     ? `Song request: ${song}`    : '',
    message ? `Message:     ${message}` : '',
    ``,
    `Submitted:   ${ts}`,
  ].filter(Boolean).join('\n');

  try {
    await ses.send(new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: { ToAddresses: [NOTIFY_EMAIL] },
      Message: {
        Subject: { Data: `RSVP: ${name} — ${isAttending ? 'Attending ✓' : 'Not attending'}` },
        Body:    { Text: { Data: emailBody } },
      },
    }));
  } catch (err) {
    // Don't fail the whole request if email fails — data is already saved
    console.error('SES error:', err);
  }

  return {
    statusCode: 200,
    headers: CORS,
    body: JSON.stringify({ success: true, id }),
  };
};
